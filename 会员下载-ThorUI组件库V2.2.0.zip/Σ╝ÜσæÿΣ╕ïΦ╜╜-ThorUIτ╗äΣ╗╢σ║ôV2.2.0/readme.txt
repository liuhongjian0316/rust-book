 注意：

 1、组件以及示例在 【ThorUI组件库】 和 【ThorUI示例】两个项目中，如果找不到文件位置尝试全局搜索
 
 2、新闻/聊天等模板在【ThorUI组件库（ThorUI-uni-vip.zip）】项目中。


zip包说明：


ThorUI-uni-vip.zip ----【ThorUI组件库】 V2.2.0 uni-app版本

ThorUI-extend-uni.zip -----【ThorUI示例】 V2.2.0 uni-app版本 （会员组件示例）

ThorUI-Hello.zip ---- ThorUI空项目，包含所有组件，uni-app版



ThorUI-applets-vip.zip -----【ThorUI组件库】 V2.2.0 微信小程序原生版本

ThorUI-extend-applets.zip ----- 【ThorUI示例】 V2.2.0 微信小程序原生版本（会员组件示例）



ThorUI-mall-uni.zip ----【商城模板】uni-app版本

ThorUI-mall-applets.zip ----【商城模板】微信小程序原生版本



温馨提示:


如果出现错误请先查看文档注意事项：https://thorui.cn/doc/docs/note.html


组件文档地址：https://thorui.cn/doc


升级指南：https://thorui.cn/doc/docs/upgrade.html

